import React from 'react'

const HeaderAdmin = () => {
  return (
    <div></div>
  )
}

export default HeaderAdmin