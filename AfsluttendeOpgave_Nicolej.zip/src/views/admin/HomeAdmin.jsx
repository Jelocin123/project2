import React from 'react'

const HomeAdmin = () => {
  return (
    <div className='mt-5 text-center'>Velkommen til admin! :)</div>
  )
}

export default HomeAdmin