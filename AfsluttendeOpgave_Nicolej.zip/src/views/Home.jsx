import React from 'react'


const Home = () => {
  return (
    
    <div className='text-center'>Velkommen til home! :)</div>
  )
}

export default Home